$("#generateButton").click(function () {
  genQrCode()
});

//var l = {}; location.search.slice(1).split("&").map(function(v){var x = v.split("="); l[x[0]] = x[1]; });
function genQrCode() {
  var sendername = $("#sendername").val();
  var pay = $("#pay").val();
  var Txn = $("#Txn").val();

  //TODO - Show Error on empty Box.
  console.log(sendername, pay, Txn);
  var str = "upi://pay?pa=" + pay + "@" + Txn +".ifsc.npci&pn=" + sendername + "&cu=INR";
  $("#payReplace").text(pay);
  $("#sendernameReplace").text(sendername);
  $("#TxnReplace").text(Txn);
  $("#box1").html("");
  var qrcode = new QRCode("box1", {
    text: str,
    width: 256,
    height: 256,
    colorDark : "#000000",
    colorLight : "#ffffff",
    correctLevel : QRCode.CorrectLevel.H
  });
}

$("#DownloadQrImage").click(function () {
  DownloadQrImage();
});

function DownloadQrImage() {
  html2canvas($("#A4Page"), {
      letterRendering: 1,
      allowTaint : true,
  		onrendered: function (canvas) {
        //document.body.appendChild(canvas)
  			canvas.toBlob(function (blob) {
  				saveAs(blob, "UPI_QR_Code.png");
  			});
  		}
  });
}
